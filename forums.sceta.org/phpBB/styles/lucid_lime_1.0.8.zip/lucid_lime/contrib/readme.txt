// ----------------------------------
//  READ ME
// -----------

Hi! Thanks for downloading the Lucid Lime style. Here you'll find some useful links
to help you get started.

// Style-specific links
FAQ:			https://www.phpbb.com/customise/db/style/lucid_lime/faq/
Support forums:	https://www.phpbb.com/customise/db/style/lucid_lime/support/

// General phpBB links
Support forums:	https://www.phpbb.com/support/forums/
Knowledge Base:	https://www.phpbb.com/kb/
Documentation:	https://www.phpbb.com/support/documentation/3.0/

// The author
My website:	http://segwin.ca/
Contact me:	Questions? Complaints? Compliments? Direct them to me at eric@segwin.ca
            	and I'll try to get back to you ASAP.
